<?php
/**
 * Database configuration
 */
define('DB_USERNAME', '16mca021');
define('DB_PASSWORD', '1186');
define('DB_HOST', 'localhost');
define('DB_NAME', '16mca021');
?>